import events.CustomPublisher;
import events.email;
import events.emailEvents;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by Dell on 7/22/2017.
 */
public class Main {


        public static void main(String[] args) {
            ConfigurableApplicationContext context =
                    new ClassPathXmlApplicationContext("Beans.xml");
            context.start();

            CustomPublisher publisher= (CustomPublisher) context.getBean("customPublisher");

            email email=new email().setToMail("abc.tothenew.com")
                    .setSubject("Test mail for Synchronous Event")
                    .setBody("Hi, \n Today's session is Spring Event and Integration");

            emailEvents emailEvent=new emailEvents(email);
            publisher.publish(emailEvent);
            context.stop();
        }
    }

