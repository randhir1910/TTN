package events;

import org.springframework.context.ApplicationEvent;

/**
 * Created by Dell on 7/22/2017.
 */
public class emailEvents  extends ApplicationEvent {
        /**
         * Create a new ApplicationEvent.
         *
         * @param source the component that published the event (never {@code null})
         */
        public emailEvents(Object source) {
            super(source);
        }

    public Object getSource() {
        return source;
    }
}

