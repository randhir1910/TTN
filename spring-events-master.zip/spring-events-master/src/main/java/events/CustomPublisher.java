package events;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;

/**
 * Created by Dell on 7/22/2017.
 */
public class CustomPublisher  implements ApplicationEventPublisherAware {


        private ApplicationEventPublisher publisher;

        @Override
        public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
            System.out.println("Application event Publisher is set to Custom Publisher");
            publisher=applicationEventPublisher;
        }

        public void publish(emailEvents event){
            publisher.publishEvent(event);
        }
    }

