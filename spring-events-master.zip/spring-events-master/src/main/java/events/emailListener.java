package events;

import org.springframework.context.ApplicationListener;

/**
 * Created by Dell on 7/22/2017.
 */
public class emailListener  implements ApplicationListener<emailEvents> {
        @Override
        public void onApplicationEvent(emailEvents event) {
            if(event.getSource() instanceof email){
                email email=(email) event.getSource();
                System.out.println(email);
            }else{
                System.out.println("Not an event class!");
            }
        }
    }

