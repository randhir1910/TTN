package events;

/**
 * Created by Dell on 7/22/2017.
 */
public class email {
    private String toMail;
    private String fromMail="miral@tothenew.com";
    private String subject;
    private String body;

    public String getToMail() {
        return toMail;
    }

    public email setToMail(String toMail) {
        this.toMail = toMail;
        return this;
    }

    public String getFromMail() {
        return fromMail;
    }

    public email setFromMail(String fromMail) {
        this.fromMail = fromMail;
        return this;
    }

    public String getSubject() {
        return subject;
    }

    public email setSubject(String subject) {
        this.subject = subject;
        return this;
    }

    public String getBody() {
        return body;
    }

    public email setBody(String body) {
        this.body = body;
        return this;
    }
}
