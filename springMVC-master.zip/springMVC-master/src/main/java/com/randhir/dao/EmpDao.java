package com.randhir.dao;

/**
 * Created by randhir on 13/7/17.
 */
public class EmpDao
{

}
